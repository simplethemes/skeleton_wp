<?php
/*-----------------------------------------------------------------------------------*/
// WooCommerce Compatibility
/*-----------------------------------------------------------------------------------*/

// Add Theme Support for WC
add_theme_support( 'woocommerce' );

// Wrap WC in native theme functions
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

add_action('woocommerce_before_main_content', 'st_content_wrap', 10);
add_action('woocommerce_after_main_content', 'st_content_wrap_close', 10);



// Disable WC styles

function st_dequeue_woo_styles( $enqueue_styles ) {
    unset( $enqueue_styles['woocommerce-general'] );
    return $enqueue_styles;
}
add_filter( 'woocommerce_enqueue_styles', 'st_dequeue_woo_styles' );



// Add custom theme styles to WC

function st_woocommmerce_styles() {
    $theme = wp_get_theme();
    $version = $theme['Version'];
    wp_register_style('woocommerce', get_bloginfo('stylesheet_directory').'/woocommerce.css', array('skeleton-style'), $version, 'screen, projection');
    wp_enqueue_style( 'woocommerce');
}
add_action('wp_enqueue_scripts','st_woocommmerce_styles');



// Adds a unique WooCommerce 'Shop' widget location

function st_woocommerce_sidebar() {
    register_sidebar( array(
        'name' => __( 'Shop', 'smpl' ),
        'id' => 'shop',
        'description' => __( 'WooCommerce Sidebar', 'smpl' ),
        'before_widget' => '<div id="%1$s" class="widget-container %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
        )
    );
}
add_action( 'init', 'st_woocommerce_sidebar' );


// 3 products per row

function loop_columns() {
    return 3;
}
add_filter('loop_shop_columns', 'loop_columns');


/**
* Optional:
* If you need to change the content ans sidebar widths for any reason, uncomment the functions below:
*/

// Set the column width
function woocommerce_filter_content_width() {
 if ( is_shop() || is_woocommerce() ) {
     return 'four';
 }
}
// Set the sidebar width
// function woocommerce_filter_sidebar_width() {
//  if ( is_shop() || is_woocommerce() ) {
//      return 'five';
//  }
// }
// Apply the content width
function set_woocommerce_filter_content_width() {
 if ( is_shop() || is_woocommerce() ) {
     add_filter('st_filter_content_width', 'woocommerce_filter_content_width');
 }
}
// Apply the sidebar width
// function set_woocommerce_filter_sidebar_width() {
//  if ( is_shop() || is_woocommerce() ) {
//      add_filter('st_sidebar_width', 'woocommerce_filter_sidebar_width');
//  }
// }
add_action('wp', 'set_woocommerce_filter_content_width');
//add_action('wp', 'set_woocommerce_filter_sidebar_width');


?>